<!--
  SPDX-License-Identifier: Apache-2.0
  SPDX-FileCopyrightText: 2021 The Elixir Team
  SPDX-FileCopyrightText: 2012 Plataformatec
-->

# Security Policy

## Supported versions

Elixir applies bug fixes only to the latest minor branch. Security patches are available for the last 5 minor branches:

Elixir version | Support
:------------- | :-----------------------------
1.21           | Development
1.20           | Bug fixes and security patches
1.19           | Security patches only
1.18           | Security patches only
1.17           | Security patches only
1.16           | Security patches only

## Announcements

New releases are announced in the read-only [announcements mailing list](https://groups.google.com/group/elixir-lang-ann) and on the [GitHub releases page](https://github.com/elixir-lang/elixir/releases).

You may also see [all releases](https://github.com/elixir-lang/elixir/releases) and [consult all disclosed vulnerabilities](https://github.com/elixir-lang/elixir/security) on GitHub.

## Reporting a vulnerability

[Please disclose security vulnerabilities privately via GitHub](https://github.com/elixir-lang/elixir/security).
