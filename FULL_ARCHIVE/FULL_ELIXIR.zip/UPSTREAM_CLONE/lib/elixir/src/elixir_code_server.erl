%% SPDX-License-Identifier: Apache-2.0
%% SPDX-FileCopyrightText: 2021 The Elixir Team
%% SPDX-FileCopyrightText: 2012 Plataformatec

-module(elixir_code_server).
-export([call/1, cast/1]).
-export([start_link/0, init/1, handle_call/3, handle_cast/2,
  handle_info/2, terminate/2, code_change/3]).
-behaviour(gen_server).

-define(timeout, infinity).
-record(elixir_code_server, {
  required=#{},
  mod_pool={[], [], 0},
  mod_ets=#{}
}).

call(Args) ->
  gen_server:call(?MODULE, Args, ?timeout).

cast(Args) ->
  gen_server:cast(?MODULE, Args).

%% Callbacks

start_link() ->
  gen_server:start_link({local, ?MODULE}, ?MODULE, ok, []).

init(ok) ->
  %% The table where we store module definitions
  _ = ets:new(elixir_modules, [set, public, named_table, {read_concurrency, true}]),
  {ok, #elixir_code_server{}}.

handle_call({defmodule, Module, Pid, Tuple}, _From, Config) ->
  case ets:lookup(elixir_modules, Module) of
    [] ->
      {Ref, NewConfig} = defmodule(Pid, Tuple, Config),
      {reply, {ok, Ref}, NewConfig};
    [CurrentTuple] ->
      {reply, {error, CurrentTuple}, Config}
  end;

handle_call({undefmodule, Ref}, _From, Config) ->
  {reply, ok, undefmodule(Ref, Config)};

handle_call({acquire, Path}, From, Config) ->
  Current = Config#elixir_code_server.required,
  case maps:find(Path, Current) of
    {ok, true} ->
      {reply, required, Config};
    {ok, Queued} when is_list(Queued) ->
      Required = maps:put(Path, [From | Queued], Current),
      {noreply, Config#elixir_code_server{required=Required}};
    error ->
      Required = maps:put(Path, [], Current),
      {reply, proceed, Config#elixir_code_server{required=Required}}
  end;

handle_call(required, _From, Config) ->
  {reply, [F || {F, true} <- maps:to_list(Config#elixir_code_server.required)], Config};

handle_call({release, Path}, _From, Config) ->
  {reply, ok, release(Path, Config)};

handle_call(retrieve_compiler_module, _From, Config) ->
  case Config#elixir_code_server.mod_pool of
    {Used, [Mod | Unused], Counter} ->
      {reply, Mod, Config#elixir_code_server{mod_pool={Used, Unused, Counter}}};
    {Used, [], Counter} ->
      {reply, compiler_module(Counter), Config#elixir_code_server{mod_pool={Used, [], Counter+1}}}
  end;

handle_call(purge_compiler_modules, _From, Config) ->
  {Used, Unused, Counter} = Config#elixir_code_server.mod_pool,
  purge_used(Used),
  Mods = [Mod || {Mod, Purgeable} <- Used, Purgeable],
  ModPool = {[], Mods ++ Unused, Counter},
  {reply, {ok, length(Used)}, Config#elixir_code_server{mod_pool=ModPool}};

handle_call(Request, _From, Config) ->
  {stop, {badcall, Request}, Config}.

handle_cast({required, Path}, Config) ->
  Current = Config#elixir_code_server.required,
  case maps:find(Path, Current) of
    {ok, true} ->
      {noreply, Config};
    {ok, Queued} ->
      _ = [gen_server:reply(From, required) || From <- lists:reverse(Queued)],
      Done = maps:put(Path, true, Current),
      {noreply, Config#elixir_code_server{required=Done}};
    error ->
      Done = maps:put(Path, true, Current),
      {noreply, Config#elixir_code_server{required=Done}}
  end;

handle_cast({unrequire_files, Files}, Config) ->
  Current  = Config#elixir_code_server.required,
  Unrequired = maps:without(Files, Current),
  {noreply, Config#elixir_code_server{required=Unrequired}};

handle_cast({return_compiler_module, Module, Purgeable}, Config) ->
  {Used, Unused, Counter} = Config#elixir_code_server.mod_pool,
  ModPool = {[{Module, Purgeable} | Used], Unused, Counter},
  {noreply, Config#elixir_code_server{mod_pool=ModPool}};

handle_cast(purge_compiler_modules, Config) ->
  {Used, Unused, Counter} = Config#elixir_code_server.mod_pool,

  case Used of
    [] -> ok;
    _ ->
      %% Purging modules became more expensive in Erlang/OTP 27+,
      %% so we accumulate them all during compilation and then
      %% purge them asynchronously, especially because they can
      %% block the code server. Ideally we would purge them in
      %% batches, but that's not supported at the moment.
      Mods = [Mod || {Mod, Purgeable} <- Used, Purgeable],
      Opts = [{monitor, [{tag, {purged, Mods}}]}],
      erlang:spawn_opt(fun() -> purge_used(Used) end, Opts)
  end,

  ModPool = {[], Unused, Counter},
  {noreply, Config#elixir_code_server{mod_pool=ModPool}};

handle_cast(Request, Config) ->
  {stop, {badcast, Request}, Config}.

handle_info({{purged, Purged}, _Ref, process, _Pid, _Reason}, Config) ->
  {Used, Unused, Counter} = Config#elixir_code_server.mod_pool,
  ModPool = {Used, Purged ++ Unused, Counter},
  {noreply, Config#elixir_code_server{mod_pool=ModPool}};

handle_info({'DOWN', Ref, process, _Pid, _Reason}, Config) ->
  {noreply, undefmodule(Ref, Config)};

handle_info(_Msg, Config) ->
  {noreply, Config}.

terminate(_Reason, _Config) ->
  ok.

code_change(_Old, Config, _Extra) ->
  {ok, Config}.

release(Path, Config) ->
  Current = Config#elixir_code_server.required,
  case maps:find(Path, Current) of
    {ok, []} ->
      Released = maps:remove(Path, Current),
      Config#elixir_code_server{required=Released};
    {ok, [Next | Waiting]} ->
      _ = gen_server:reply(Next, proceed),
      Released = maps:put(Path, Waiting, Current),
      Config#elixir_code_server{required=Released};
    error ->
      Config
  end.

compiler_module(I) ->
  list_to_atom("elixir_compiler_" ++ integer_to_list(I)).

purge_used(Used) ->
  [begin
    code:delete(Module),
    Purgeable andalso code:purge(Module)
  end || {Module, Purgeable} <- Used],
  ok.

defmodule(Pid, Tuple, #elixir_code_server{mod_ets=ModEts} = Config) ->
  ets:insert(elixir_modules, Tuple),
  Ref = erlang:monitor(process, Pid),
  Mod = erlang:element(1, Tuple),
  {Ref, Config#elixir_code_server{mod_ets=maps:put(Ref, Mod, ModEts)}}.

undefmodule(Ref, #elixir_code_server{mod_ets=ModEts} = Config) ->
  case maps:find(Ref, ModEts) of
    {ok, Mod} ->
      ets:delete(elixir_modules, Mod),
      Config#elixir_code_server{mod_ets=maps:remove(Ref, ModEts)};
    error ->
      Config
  end.
