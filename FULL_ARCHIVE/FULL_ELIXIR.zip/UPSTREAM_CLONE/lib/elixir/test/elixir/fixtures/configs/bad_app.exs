[sample: :oops]
